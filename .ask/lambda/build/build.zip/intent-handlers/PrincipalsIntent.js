"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrincipalsIntent = void 0;
const ask_sdk_core_1 = require("ask-sdk-core");
const i18next_1 = __importDefault(require("i18next"));
const constants_1 = require("../utils/constants");
const helpers_1 = require("../utils/helpers");
exports.PrincipalsIntent = {
    canHandle(handlerInput) {
        console.log((0, ask_sdk_core_1.getIntentName)(handlerInput.requestEnvelope));
        return (0, helpers_1.isIntent)(handlerInput, constants_1.IntentTypes.Principals);
    },
    handle(handlerInput) {
        console.log('handling principal');
        const principalNumber = (0, ask_sdk_core_1.getSlotValue)(handlerInput.requestEnvelope, 'number');
        if (principalNumber === null || principalNumber === undefined) {
            return handlerInput.responseBuilder
                .speak(i18next_1.default.t(constants_1.STRING_KEYS.PRINCIPALS_INTRO))
                .getResponse();
        }
        switch (principalNumber) {
            case '1st':
                return handlerInput.responseBuilder
                    .speak(i18next_1.default.t(constants_1.STRING_KEYS.PRINCIPALS_FIRST))
                    .reprompt(i18next_1.default.t(constants_1.STRING_KEYS.PRINCIPALS_FIRST_REPORMPT))
                    .getResponse();
            default:
                break;
        }
    }
};
//# sourceMappingURL=PrincipalsIntent.js.map